stylesheet_main = """
            MainWindow {
                background-image: url("main.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_choice = """
            ChoiceWindow {
                background-image: url("choice_game.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_rol = """
                LogOrRegWindow {
                    background-image: url("acc_new_or_old.png"); 
                    background-repeat: no-repeat; 
                    background-position: center;
                }
            """

stylesheet_acc = """
                            AccWindow {
                                background-image: url("acc_bg.png"); 
                                background-repeat: no-repeat; 
                                background-position: center;
                            }
                        """

stylesheet_reg = """
            RegWindow {
                background-image: url("registration.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_log = """
            LogWindow {
                background-image: url("login_in_system.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_lvl = """
            LvlWindow {
                background-image: url("complexity.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_prob = """
            ProbSolvWindow {
                background-image: url("problem_solving.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_vikt = """
            ViktWindow {
                background-image: url("viktorina.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_kaz = """
            KazWindow {
                background-image: url("kazino.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_slot = """
            SlotWindow {
                background-image: url("sloty.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_promo = """
            PromoWindow {
                background-image: url("promos.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_crash = """
            CrashKazWindow {
                background-image: url("crash.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_top = """
            TopWindow {
                background-image: url("top.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_shop = """
            ShopWindow {
                background-image: url("shop.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """

stylesheet_invent = """
            InventWindow {
                background-image: url("invent.png"); 
                background-repeat: no-repeat; 
                background-position: center;
            }
        """